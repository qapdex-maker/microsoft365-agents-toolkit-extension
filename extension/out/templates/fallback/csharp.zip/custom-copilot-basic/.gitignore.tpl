# TeamsFx files
build
appPackage/build
env/.env.*.user
env/.env.local
appsettings.Development.json
appsettings.Playground.json
.deployment

# User-specific files
*.user

# Build results
[Dd]ebug/
[Dd]ebugPublic/
[Rr]elease/
[Rr]eleases/
x64/
x86/
bld/
[Bb]in/
[Oo]bj/
[Ll]og/

# Notification local store
.notification.localstore.json
.notification.playgroundstore.json

# devTools
devTools/