{
  "profiles": {
    // Launch project within Microsoft 365 Agents Playground
    "Microsoft 365 Agents Playground (browser)": {
      "commandName": "Project",
      "environmentVariables": { 
        "UPDATE_TEAMS_APP": "false",
        "M365_AGENTS_PLAYGROUND_TARGET_SDK": "teams-ai-v2-dotnet"
      },
      "launchTestTool": true,
      "launchUrl": "http://localhost:56150"
    },
    // Launch project within Teams
    "Microsoft Teams (browser)": {
      "commandName": "Project",
      "launchUrl": "https://teams.microsoft.com/l/app/${{TEAMS_APP_ID}}?installAppPackage=true&webjoin=true&appTenantId=${{TEAMS_APP_TENANT_ID}}&login_hint=${{TEAMSFX_M365_USER_NAME}}"
    },
    // Launch project within Teams without prepare app dependencies
    "Microsoft Teams (browser) (skip update app)": {
      "commandName": "Project",
      "environmentVariables": { "UPDATE_TEAMS_APP": "false" },
      "launchUrl": "https://teams.microsoft.com/l/app/${{TEAMS_APP_ID}}?installAppPackage=true&webjoin=true&appTenantId=${{TEAMS_APP_TENANT_ID}}&login_hint=${{TEAMSFX_M365_USER_NAME}}"
    }
  }
}